// server.js - Stock Grader proxy for Yahoo Finance
// Usage: node server.js
const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = process.env.PORT || 8080;

const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX || '120'),
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests, slow down' }
});

app.use(cors());
app.use(express.json());
app.use(limiter);

const cacheMap = new Map();
const CACHE_TTL_MS = (process.env.CACHE_TTL_SEC ? parseInt(process.env.CACHE_TTL_SEC) : 60) * 1000;

function getCache(key) {
  const row = cacheMap.get(key);
  if (!row) return null;
  if (Date.now() - row.ts > CACHE_TTL_MS) {
    cacheMap.delete(key);
    return null;
  }
  return row.value;
}

function setCache(key, value) {
  cacheMap.set(key, { ts: Date.now(), value });
}

async function fetchYahoo(symbols) {
  const qs = encodeURIComponent(symbols.join(','));
  const url = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${qs}`;
  const res = await fetch(url, { method: 'GET' });
  if (!res.ok) throw new Error('Yahoo fetch failed ' + res.status);
  const j = await res.json();
  return (j && j.quoteResponse && j.quoteResponse.result) || [];
}

app.get('/api/quote', async (req, res) => {
  try {
    const symbolsRaw = (req.query.symbols || '').toString().trim();
    if (!symbolsRaw) return res.status(400).json({ error: 'symbols required' });

    const syms = Array.from(new Set(symbolsRaw.split(/[\s,]+/).map(s => s.trim().toUpperCase()).filter(Boolean)));
    if (!syms.length) return res.status(400).json({ error: 'no valid symbols' });

    const cachedResults = [];
    const toFetch = [];

    for (const s of syms) {
      const key = `yq:${s}`;
      const cached = getCache(key);
      if (cached) cachedResults.push(cached);
      else toFetch.push(s);
    }

    const resultsFetched = [];
    const BATCH_SIZE = parseInt(process.env.BATCH_SIZE || '10');

    for (let i=0;i<toFetch.length;i+=BATCH_SIZE) {
      const batch = toFetch.slice(i,i+BATCH_SIZE);
      const fetched = await fetchYahoo(batch);
      for (const item of fetched) {
        const key = `yq:${(item && item.symbol) || ''}`;
        setCache(key, item);
        resultsFetched.push(item);
      }
      if (toFetch.length > BATCH_SIZE) {
        await new Promise(r => setTimeout(r, parseInt(process.env.BATCH_DELAY_MS || '200')));
      }
    }

    const combined = [...cachedResults, ...resultsFetched];
    const bySym = new Map();
    for (const it of combined) if (it && it.symbol) bySym.set(it.symbol.toUpperCase(), it);
    const ordered = syms.map(s => bySym.get(s) || null);
    res.json({ source: 'proxy', data: ordered });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/health', (req, res) => res.json({ ok:true, ts: Date.now() }));

app.listen(PORT, () => console.log(`Stock Grader proxy listening on ${PORT}`));
