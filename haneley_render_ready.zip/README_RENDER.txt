HANELEY Stock Grader — Render deploy guide
=========================================

Files included:
- server.js
- package.json
- Dockerfile
- frontend_via_backend.html
- render.yaml

Quick local test (optional):
1. Install Node.js v16+
2. In project folder run:
   npm install
   npm start
3. Server starts on http://localhost:8080
4. Open frontend_via_backend.html and set Backend URL to http://localhost:8080

Deploy to Render (steps):
1. Create a GitHub repo and push these files.
2. Sign in to https://render.com and click "New" -> "Web Service".
3. Connect your GitHub repo, select the repo, branch `main`.
4. For Environment choose "Node" (or Docker if you prefer). Render will run `npm install` then `npm start` by default.
5. After deploy, Render assigns a URL like https://haneley-stock-grader.onrender.com. You can rename the service to `haneley` in settings to get https://haneley.onrender.com if available.
6. Open the frontend file and set Backend URL to the deployed Render URL.
Notes:
- If you hit rate limits, increase `BATCH_SIZE` or deploy with Redis and update server accordingly.
- Render may take ~1-2 minutes for first deploy.

Troubleshoot:
- If fetch returns nulls, check server logs on Render (Web Service -> Logs).
- If CORS errors persist, ensure the frontend calls the Render URL (https) and not file:// path.
